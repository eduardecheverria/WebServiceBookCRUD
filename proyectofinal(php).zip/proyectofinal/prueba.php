<?php
require 'vendor/autoload.php';
function object_to_array($data)
{
    if (is_array($data) || is_object($data))
    {
        $result = array();
        foreach ($data as $key => $value)
        {
            $result[$key] = object_to_array($value);
        }
        return $result;
    }
    return $data;
}
function getProd2($user, $pass, $categoria) {
    $categoria = strtolower($categoria);
    $collection_user="usuarios/".$user;
    $buscar_password=read_collection($collection_user);
    $collection_categoria="productos/".$categoria;
    $buscar_categoria=read_collection($collection_categoria);
    /**
    NUEVO
    **/
    $resp = array(
        'code'    => 999,
        'message' => read_collection("respuestas/999"),
        'data'    => '',
        'status'  => 'error'
    );

    if ($buscar_password!=NULL ) {
        if ( $buscar_password === $pass ) {
            if (getRolUsuario($user)==="almacen"||getRolUsuario($user)==="ventas") {
                if ( $buscar_categoria!=NULL ) {
                    $resp['code'] = 200;
                    $resp['message'] = read_collection("respuestas/200");
                    $resp['status'] = 'success';
                    $prueba=object_to_array($buscar_categoria);
                    $prueba= array_values($prueba);
                    $prueba=json_encode($prueba);
                    var_dump($prueba);
                    $resp['data'] = json_encode($buscar_categoria, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                }
                else {
                    $resp['code'] = 300;
                    $resp['message'] = read_collection("respuestas/300");
                }
            }
            else{
                $resp['code'] = 506;
                $resp['message'] = read_collection("respuestas/506");
            }
        }
        else {
            $resp['code'] = 501;
            $resp['message'] = read_collection("respuestas/501");
        }
    }
    else {
        $resp['code'] = 500;
        $resp['message'] = read_collection("respuestas/500");
    }

    return $resp;
}
getProd2("pruebas1", "12345678a", "libros");
?>