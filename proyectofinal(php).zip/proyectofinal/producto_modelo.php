<?php
	//header("Content-Type: text/xml; charset=UTF-8\r\n");
    require_once('nusoap/lib/nusoap.php');
    // opis library validation json schema
    require __DIR__ . '/vendor/autoload.php';
    use Opis\JsonSchema\{
        Validator, ValidationResult, ValidationError, Schema
    };
    
    function create_collection($collection,$data) {
        $url = "https://proyectofinal-8922a-default-rtdb.firebaseio.com/productosws-c9f47-default-rtdb/".$collection.".json";

        $ch =  curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PATCH" ); 
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: text/plain"));
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        
        curl_close($ch);

        // Se convierte a Object o NULL
        return json_decode($response);
    }  

    function read_collection($collection) {
        $url = "https://proyectofinal-8922a-default-rtdb.firebaseio.com/productosws-c9f47-default-rtdb/".$collection.".json";

        $ch =  curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);

        curl_close($ch);

        // Se convierte a Object o NULL
        return json_decode($response);
    }

    function update_collection($collection,$data) {
        $url = "https://proyectofinal-8922a-default-rtdb.firebaseio.com/productosws-c9f47-default-rtdb/".$collection.".json";

        $ch =  curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PATCH" ); 
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: text/plain"));
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        
        curl_close($ch);

        // Se convierte a Object o NULL
        return json_decode($response);
    }

    function delete_collection($collection) {
        $url = "https://proyectofinal-8922a-default-rtdb.firebaseio.com/productosws-c9f47-default-rtdb/".$collection.".json";

        $ch =  curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
        $response = curl_exec($ch);
    
        // Si no se obtuvieron resultados, entonces no existe la colección
        if( is_null(json_decode($response)) ) {
            $resBool =  false;
        } else {    // Si existe la colección, entonces se procede a eliminar la colección
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE" ); 
            curl_exec($ch);
            $resBool =  true;
        }
        
        curl_close($ch);
    
        // Se devuelve true o false
        return $resBool;
    }

    function object_to_array($data)
    {
        if (is_array($data) || is_object($data))
        {
            $result = array();
            foreach ($data as $key => $value)
            {
                $result[$key] = object_to_array($value);
            }
            return $result;
        }
        return $data;
    }

    function tieneNumero($string){
        $i=0;
        while($i < strlen($string) ){
            if(is_numeric($string[$i])){
                return 1;
            }
            $i++;
        }
        return 0;
    }

    function getisbn($prodJSON){
        $auxiliar=json_decode($prodJSON,true);
        return $auxiliar['isbn'];
     }
     function getName($prodJSON){
        $auxiliar=json_decode($prodJSON,true);
        return $auxiliar['nombre'];
     }
    

     function json_validate($string) {
        // decode the JSON data
        $result = json_decode($string);
    
        // switch and check possible JSON errors
        switch (json_last_error()) {
            case JSON_ERROR_NONE:
                $error = ''; // JSON is valid // No error has occurred
                break;
            case JSON_ERROR_DEPTH:
                $error = 'The maximum stack depth has been exceeded.';
                break;
            case JSON_ERROR_STATE_MISMATCH:
                $error = 'Invalid or malformed JSON.';
                break;
            case JSON_ERROR_CTRL_CHAR:
                $error = 'Control character error, possibly incorrectly encoded.';
                break;
            case JSON_ERROR_SYNTAX:
                $error = 'Syntax error, malformed JSON.';
                break;
            // PHP >= 5.3.3
            case JSON_ERROR_UTF8:
                $error = 'Malformed UTF-8 characters, possibly incorrectly encoded.';
                break;
            // PHP >= 5.5.0
            case JSON_ERROR_RECURSION:
                $error = 'One or more recursive references in the value to be encoded.';
                break;
            // PHP >= 5.5.0
            case JSON_ERROR_INF_OR_NAN:
                $error = 'One or more NAN or INF values in the value to be encoded.';
                break;
            case JSON_ERROR_UNSUPPORTED_TYPE:
                $error = 'A value of a type that cannot be encoded was given.';
                break;
            default:
                $error = 'Unknown JSON error occured.';
                break;
        }
        return $error;
     }

     function validar_formaJson($data){
        $data = json_decode($data);
        $schema = Schema::fromJsonString(file_get_contents('schema.json'));
    
        $validator = new Validator();
    
        /** @var ValidationResult $result */
        $result = $validator->schemaValidation($data, $schema);
    
        if ($result->isValid()) {
            return "";
        } else {
            /** @var ValidationError $error */
            $error = $result->getFirstError();
            return "FALSE";
        }
    }

    function getRolUsuario($user){
        $rol_usuario=read_collection("information/".$user);
        $rol_usuario=json_encode($rol_usuario);
        $rol_usuario=json_decode($rol_usuario);
        return $rol_usuario->rol;
    }

    function getProd($user, $pass, $categoria) {
        $categoria = strtolower($categoria);
        $collection_user="usuarios/".$user;
        $buscar_password=read_collection($collection_user);
        $collection_categoria="productos/".$categoria;
        $buscar_categoria=read_collection($collection_categoria);
        /**
        NUEVO
        **/
        $resp = array(
            'code'    => 999,
            'message' => read_collection("respuestas/999"),
            'data'    => '',
            'status'  => 'error'
        );

        if ($buscar_password!=NULL ) {
            if ( $buscar_password === $pass ) {
                if (getRolUsuario($user)==="almacen"||getRolUsuario($user)==="ventas") {
                    if ( $buscar_categoria!=NULL ) {
                        $resp['code'] = 200;
                        $resp['message'] = read_collection("respuestas/200");
                        $resp['status'] = 'success';
                        $buscar_categoria=object_to_array($buscar_categoria);
                        $buscar_categoria= array_values($buscar_categoria);
                        //$buscar_categoria=json_encode($buscar_categoria);
                        $resp['data'] = json_encode($buscar_categoria, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                    }
                    else {
                        $resp['code'] = 300;
                        $resp['message'] = read_collection("respuestas/300");
                    }
                }
                else{
                    $resp['code'] = 506;
                    $resp['message'] = read_collection("respuestas/506");
                }
            }
            else {
                $resp['code'] = 501;
                $resp['message'] = read_collection("respuestas/501");
            }
        }
        else {
            $resp['code'] = 500;
            $resp['message'] = read_collection("respuestas/500");
        }

        return $resp;
    }

    function getDetails($user, $pass, $isbn) {
        $collection_user="usuarios/".$user;
        $buscar_password=read_collection($collection_user);
        $buscar_isbn=read_collection("detalles/".$isbn);
        /**
        NUEVO
        **/
        $resp = array(
            'code'    => 999,
            'message' => read_collection("respuestas/999"),
            'data'    => '',
            'status'  => 'error',
            'oferta'  => false
        );

        if ( $buscar_password!=NULL ) {
            if ( $buscar_password === $pass) {
                if (getRolUsuario($user)==="almacen"||getRolUsuario($user)==="ventas") {
                    if ( $buscar_isbn!=NULL ) {
                        $resp['code'] = 200;
                        $resp['message'] = read_collection("respuestas/200");
                        $resp['status'] = "success";
                        $resp['data'] = json_encode($buscar_isbn, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                        $resp['oferta'] = strval(read_collection("detalles/".$isbn."/editorial"))==='editorialY'?true:false;
                    }
                    else {
                        $resp['code'] = 301;
                        $resp['message'] = read_collection("respuestas/301");
                    }
                }
                else{
                    $resp['code'] = 506;
                    $resp['message'] = read_collection("respuestas/506");
                }
            }
            else {
                $resp['code'] = 501;
                $resp['message'] = read_collection("respuestas/501");
            }
        }
        else {
            $resp['code'] = 500;
            $resp['message'] = read_collection("respuestas/500");
        }

        return $resp;
    }

    function setProd($user, $pass, $prodJSON) {
        $collection_user="usuarios/".$user;
        $buscar_password=read_collection($collection_user);
        $buscar_isbn=read_collection("detalles/".getisbn($prodJSON));
        /**
        NUEVO
        **/
        $resp = array(
            'code'    => 999,
            'message' => read_collection("respuestas/999"),
            'data'    => '',
            'status'  => 'error'
        );

        if(json_validate($prodJSON)!=''){
            $resp['code'] = 305;
            $resp['message'] = read_collection("respuestas/305");
            return $resp;
        }

        if(validar_formaJson($prodJSON)=="FALSE"){
            $resp['code'] = 304;
            $resp['message'] = read_collection("respuestas/304");
            return $resp;
        }

        if ( $buscar_password!=NULL ) {
            if ( $buscar_password === $pass ) {
                if (getRolUsuario($user)==="almacen") {
                    if ( $buscar_isbn==NULL ) {
                        if(create_collection("detalles/".getisbn($prodJSON)."",$prodJSON)!=NULL){
                            $newProd='{
                                "isbn":"'.getisbn($prodJSON).'",
                                "nombre":"'.getName($prodJSON).'"
                            }';
                            if(getisbn($prodJSON)[0]=="M"){
                                $categoria="mangas";
                            }
                            if(getisbn($prodJSON)[0]=="C"){
                                $categoria="comics";
                            }
                            if(getisbn($prodJSON)[0]=="L"){
                                $categoria="libros";
                            }
                            create_collection("productos/".$categoria."/".getisbn($prodJSON)."",$newProd);
                            date_default_timezone_set('America/Mexico_City');
                            $hoy = getdate();
                            $resp['code'] = 202;
                            $resp['message'] = read_collection("respuestas/202");
                            $resp['status'] = "success";
                            $resp['data'] = "".$hoy['year']."-".$hoy['mon']."-".$hoy['mday']."T".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds']."";
                        }
                        
                    }
                    else {
                        $resp['code'] = 302;
                        $resp['message'] = read_collection("respuestas/302");
                    }
                }
                else{
                    $resp['code'] = 506;
                    $resp['message'] = read_collection("respuestas/506");
                }
            }
            else {
                $resp['code'] = 501;
                $resp['message'] = read_collection("respuestas/501");
            }
        }
        else {
            $resp['code'] = 500;
            $resp['message'] = read_collection("respuestas/500");
        }

        return $resp;
    }

    function updateProd($user, $pass, $prodJSON) {
        $collection_user="usuarios/".$user;
        $buscar_password=read_collection($collection_user);
        $buscar_isbn=read_collection("detalles/".getisbn($prodJSON));
        /**
        NUEVO
        **/
        $resp = array(
            'code'    => 999,
            'message' => read_collection("respuestas/999"),
            'data'    => '',
            'status'  => 'error'
        );

        if(json_validate($prodJSON)!=''){
            $resp['code'] = 305;
            $resp['message'] = read_collection("respuestas/305");
            return $resp;
        }

        if(validar_formaJson($prodJSON)=="FALSE"){
            $resp['code'] = 304;
            $resp['message'] = read_collection("respuestas/304");
            return $resp;
        }

        if ( $buscar_password!=NULL ) {
            if ( $buscar_password === $pass) {
                if (getRolUsuario($user)==="almacen") {
                    if ( $buscar_isbn!=NULL ) {
                        if(update_collection("detalles/".getisbn($prodJSON),$prodJSON)!=NULL){
                            $newProd='{
                                "isbn":"'.getisbn($prodJSON).'",
                                "nombre":"'.getName($prodJSON).'"
                            }';
                            if(getisbn($prodJSON)[0]=="M"){
                                $categoria="mangas";
                            }
                            if(getisbn($prodJSON)[0]=="C"){
                                $categoria="comics";
                            }
                            if(getisbn($prodJSON)[0]=="L"){
                                $categoria="libros";
                            }
                            create_collection("productos/".$categoria."/".getisbn($prodJSON)."",$newProd);
                            date_default_timezone_set('America/Mexico_City');
                            $hoy = getdate();
                            $resp['code'] = 203;
                            $resp['message'] = read_collection("respuestas/203");
                            $resp['status'] = "success";
                            $resp['data'] = "".$hoy['year']."-".$hoy['mon']."-".$hoy['mday']."T".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds']."";
                        }
                        
                    }
                    else {
                        $resp['code'] = 303;
                        $resp['message'] = read_collection("respuestas/303");
                    }
                }
                else{
                    $resp['code'] = 506;
                    $resp['message'] = read_collection("respuestas/506");
                }
            }
            else {
                $resp['code'] = 501;
                $resp['message'] = read_collection("respuestas/501");
            }
        }
        else {
            $resp['code'] = 500;
            $resp['message'] = read_collection("respuestas/500");
        }

        return $resp;
    }

    function deleteProd($user, $pass, $isbn) {
        $collection_user="usuarios/".$user;
        $buscar_password=read_collection($collection_user);
        $buscar_isbn=read_collection("detalles/".$isbn);
        /**
        NUEVO
        **/
        $resp = array(
            'code'    => 999,
            'message' => read_collection("respuestas/999"),
            'data'    => '',
            'status'  => 'error'
        );

        if ( $buscar_password!=NULL ) {
            if ( $buscar_password === $pass) {
                if (getRolUsuario($user)==="almacen") {
                    if ( $buscar_isbn!=NULL ) {
                        if(delete_collection("detalles/".$isbn)!=false){
                            if($isbn[0]=="M"){
                                $categoria="mangas";
                            }
                            if($isbn[0]=="C"){
                                $categoria="comics";
                            }
                            if($isbn[0]=="L"){
                                $categoria="libros";
                            }
                            delete_collection("productos/".$categoria."/".$isbn."");
                            date_default_timezone_set('America/Mexico_City');
                            $hoy = getdate();
                            //delete_collection("detalles/".$isbn);
                            $resp['code'] = 204;
                            $resp['message'] = read_collection("respuestas/204");
                            $resp['status'] = "success";
                            $resp['data'] = "".$hoy['year']."-".$hoy['mon']."-".$hoy['mday']."T".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds']."";
                        }
                        
                    }
                    else {
                        $resp['code'] = 303;
                        $resp['message'] = read_collection("respuestas/303");
                    }
                }
                else{
                    $resp['code'] = 506;
                    $resp['message'] = read_collection("respuestas/506");
                }
            }
            else {
                $resp['code'] = 501;
                $resp['message'] = read_collection("respuestas/501");
            }
        }
        else {
            $resp['code'] = 500;
            $resp['message'] = read_collection("respuestas/500");
        }

        return $resp;
    }

    function updatePassword($user, $pass, $newPass) {
        $collection_user="usuarios/".$user;
        $buscar_password=read_collection($collection_user);
        /**
        NUEVO
        **/
        $resp = array(
            'code'    => 999,
            'message' => read_collection("respuestas/999"),
            'status'  => 'error',
        );

        if ( $buscar_password!=NULL ) {
            if ( $buscar_password === $pass ) {
                if (getRolUsuario($user)==="almacen"||getRolUsuario($user)==="ventas") {
                    if ( strlen ($newPass) >= 8 &&  tieneNumero($newPass) == 1) {
                        if(update_collection("usuarios",'{"'.$user.'":"'.$newPass.'"}')!=NULL){
                            date_default_timezone_set('America/Mexico_City');
                            $hoy = getdate();
                            $resp['code'] = 400;
                            $resp['message'] = read_collection("respuestas/400");
                            $resp['data'] = "".$hoy['year']."-".$hoy['mon']."-".$hoy['mday']."T".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds']."";
                            $resp['status'] = "success";
                        }
                        else{
                            $resp['code'] = 401;
                            $resp['message'] = read_collection("respuestas/401");
                        }
                    }
                    else {
                        $resp['code'] = 502;
                        $resp['message'] = read_collection("respuestas/502");
                    }
                }
                else{
                    $resp['code'] = 506;
                    $resp['message'] = read_collection("respuestas/506");
                }
            }
            else {
                $resp['code'] = 501;
                $resp['message'] = read_collection("respuestas/501");
            }
        }
        else {
            $resp['code'] = 500;
            $resp['message'] = read_collection("respuestas/500");
        }

        return $resp;
    }
    function login($user,$password){
        $collection_user="usuarios/".$user;
        $buscar_password=read_collection($collection_user);
        $resp = array(
            'code'    => 999,
            'message' => read_collection("respuestas/999"),
            'status'  => 'error',
        );
        if ( $buscar_password!=NULL ) {
            if ( $buscar_password === $password ) {
                date_default_timezone_set('America/Mexico_City');

                $hoy = getdate();
                $resp['code'] = 205;
                $resp['message'] = read_collection("respuestas/205");
                $resp['data'] = getRolUsuario($user);
                $resp['status'] = "success";
            }
            else {
                $resp['code'] = 501;
                $resp['message'] = read_collection("respuestas/501");
            }
        }
        else {
            $resp['code'] = 500;
            $resp['message'] = read_collection("respuestas/500");
        }

        return $resp;
    }
    // Exposición del servicio (WSDL) PHP v7.2 o superior
   
?>